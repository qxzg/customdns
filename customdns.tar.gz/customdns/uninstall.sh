#!/bin/sh

rm /koolshare/configs/custom_dns.conf
rm /koolshare/res/icon-customdns.png
rm /koolshare/scripts/customdns*
rm /koolshare/scripts/uninstall_customdns.sh
rm /koolshare/webs/Module_customdns.asp
